-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 2018-08-03 05:31:51
-- 服务器版本： 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bug`
--

-- --------------------------------------------------------

--
-- 表的结构 `sp_edit`
--

DROP TABLE IF EXISTS `sp_edit`;
CREATE TABLE IF NOT EXISTS `sp_edit` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `title` text NOT NULL COMMENT '文章标题',
  `content` text NOT NULL COMMENT '文章内容',
  `image` varchar(150) DEFAULT '' COMMENT '上传的图片',
  `ctime` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='页面编辑表';

--
-- 转存表中的数据 `sp_edit`
--

INSERT INTO `sp_edit` (`id`, `title`, `content`, `image`, `ctime`) VALUES
(1, '英国女王与特朗普阅兵，后者意外“挡道”', '&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;特朗普去了英国，成为女王伊丽莎白二世会见的第12位美国总统。&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;一般来说，要抢女王风头是非常困难的，但特朗普做到了。&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;综合外媒报道，当地时间7月13日，特朗普在温莎城堡与伊丽莎白二世会面，在欢迎仪式上，女王与特朗普一同检阅仪仗队。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;large&quot; data-loadfunc=&quot;0&quot; src=&quot;https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=641404915,4267540154&amp;fm=173&amp;app=25&amp;f=JPEG?w=620&amp;h=399&amp;s=C7309AE01F728FDC12D04CA703007042&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; width: 537px; display: block;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;女王开始走在特朗普身后，不知是否为了等女王，特朗普突然停下来，伊丽莎白二世不得不绕着他走。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;normal&quot; width=&quot;320px&quot; data-loadfunc=&quot;0&quot; src=&quot;https://hiphotos.baidu.com/feed/pic/item/e850352ac65c10380258ff2bbe119313b07e8930.jpg&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; display: block; margin: 0px auto;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;走到特朗普身边时，女王向他做了个手势，似乎示意他继续向前走。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;normal&quot; width=&quot;333px&quot; data-loadfunc=&quot;0&quot; src=&quot;https://hiphotos.baidu.com/feed/pic/item/9825bc315c6034a80c78b368c713495408237644.jpg&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; display: block; margin: 0px auto;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;之后，两人一同检阅仪仗队，92岁高龄的女王步速明显更快。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;normal&quot; width=&quot;319px&quot; data-loadfunc=&quot;0&quot; src=&quot;https://hiphotos.baidu.com/feed/pic/item/9345d688d43f8794226543c7de1b0ef41ad53a44.jpg&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; display: block; margin: 0px auto;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;早前，特朗普在接受英国《太阳报》采访时，称赞伊丽莎白二世是个“了不起的女人”，他说“我真的很期待见到她，我认为她很好地代表了她的国家。”&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;“她从未犯过错误，不会有令人尴尬的事情，她是个不可思议的女人。”&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;媒体也没放过一切“黑”特朗普的机会。据路透社报道，当天女王是“微笑着迎接”特朗普和梅拉尼娅夫妇的，不过在等候他们到来时候，还是看了眼手表。&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;本文系观察者网独家稿件，未经授权，不得转载。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', './Public/Uploads/2018-07-10/5b4480bb54029.jpg', NULL),
(2, 'niaho', '支撑经济迈向高质量发展的有利条件积累增多&lt;/strong&gt;　　上半年，中国经济运行表现良好，下半年，面临的挑战也依然复杂。中美经贸摩擦对中国经济有何影响，引起各界广泛关注。　　“总的来说，在世界经济深度融合的当下，由美国单方面挑起的中美贸易摩擦对中美两国经济都会产生影响，也会影响全球经济的复苏和世界贸易的持续增长。”毛盛勇说，中美贸易摩擦对中国居民消费价格的影响有限，进口大豆价格可能会有一定的上升，会带来豆制品及相关产品价格的一些变化。但大豆及豆类相关产品在CPI的权重比较小，对整个CPI的影响非常有限。从下半年趋势看，居民消费价格有望延续温和上涨态势。　　总的看，上半年国民经济延续总体平稳、稳中向好的发展态势，支撑经济迈向高质量发展的有利条件积累增多，为实现全年经济社会主要发展目标打下良好基础。　　消费仍是顶梁柱。“从今年上半年主要的数据来看，经济增长的格局中，内需是决定力量，内需里面消费又是顶梁柱。从下半年来看，消费还是有条件延续平稳较快的增长态势。”毛盛勇说，消费保持较快增长有四大理由：一是消费本身是刚性增长；二是居民收入总体保持较快增长，而消费是收入的函数；三是基于我国经济发展阶段，消费结构升级的步伐只会加快；四是不断地满足人民日益增长的美好生活需要，加大了进口，丰富了供给，也会促进市场销售的活跃。　　投资保持稳定性。从投资的三大领域看，制造业投资连续3个月增速加快，良好的增长势头有望延续；上半年房屋新开工面积在加快，土地购置面积和土地购置费增长加快，这两个先行指标向好预示着下半年房地产投资有望保持较快增长；此外，随着项目清理完成，合规项目加快落地进度，基础设施投资下半年也有望保持基本稳定。　　“我国当前正处在结构调整转型升级的攻关期，下一步，要坚持推进供给侧结', '', NULL),
(3, '价值', '支撑经济迈向高质量发展的有利条件积累增多&lt;/strong&gt;　　上半年，中国经济运行表现良好，下半年，面临的挑战也依然复杂。中美经贸摩擦对中国经济有何影响，引起各界广泛关注。　　“总的来说，在世界经济深度融合的当下，由美国单方面挑起的中美贸易摩擦对中美两国经济都会产生影响，也会影响全球经济的复苏和世界贸易的持续增长。”毛盛勇说，中美贸易摩擦对中国居民消费价格的影响有限，进口大豆价格可能会有一定的上升，会带来豆制品及相关产品价格的一些变化。但大豆及豆类相关产品在CPI的权重比较小，对整个CPI的影响非常有限。从下半年趋势看，居民消费价格有望延续温和上涨态势。　　总的看，上半年国民经济延续总体平稳、稳中向好的发展态势，支撑经济迈向高质量发展的有利条件积累增多，为实现全年经济社会主要发展目标打下良好基础。　　消费仍是顶梁柱。“从今年上半年主要的数据来看，经济增长的格局中，内需是决定力量，内需里面消费又是顶梁柱。从下半年来看，消费还是有条件延续平稳较快的增长态势。”毛盛勇说，消费保持较快增长有四大理由：一是消费本身是刚性增长；二是居民收入总体保持较快增长，而消费是收入的函数；三是基于我国经济发展阶段，消费结构升级的步伐只会加快；四是不断地满足人民日益增长的美好生活需要，加大了进口，丰富了供给，也会促进市场销售的活跃。　　投资保持稳定性。从投资的三大领域看，制造业投资连续3个月增速加快，良好的增长势头有望延续；上半年房屋新开工面积在加快，土地购置面积和土地购置费增长加快，这两个先行指标向好预示着下半年房地产投资有望保持较快增长；此外，随着项目清理完成，合规项目加快落地进度，基础设施投资下半年也有望保持基本稳定。　　“我国当前正处在结构调整转型升级的攻关期，下一步，要坚持推进供给侧结&lt;img src=\"http://www.test.com/Public/umeditor1_2_2-utf8-php/php/upload/20180717/15318215522006.jpg\" alt=\"15318215522006.jpg\" /&gt;', '', NULL),
(4, '图库', '&lt;p&gt;大叔发送到发送到&lt;/p&gt;', '', NULL),
(5, 'LED显示屏充分发挥户外广告传媒理念', '&lt;p&gt;ad发多少xcvzvxcxz zx&lt;/p&gt;', '', 1531993144);

-- --------------------------------------------------------

--
-- 表的结构 `sp_manager`
--

DROP TABLE IF EXISTS `sp_manager`;
CREATE TABLE IF NOT EXISTS `sp_manager` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `username` varchar(32) NOT NULL COMMENT '姓名',
  `pwd` varchar(32) NOT NULL COMMENT '密码',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sp_manager`
--

INSERT INTO `sp_manager` (`id`, `username`, `pwd`, `status`) VALUES
(1, 'admin', '123456', 1),
(2, 'tom', '123456', 1),
(3, 'hai', '3', 1),
(4, '袁江平', '123456', 1);

-- --------------------------------------------------------

--
-- 表的结构 `sp_privilege`
--

DROP TABLE IF EXISTS `sp_privilege`;
CREATE TABLE IF NOT EXISTS `sp_privilege` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `pri_name` varchar(20) NOT NULL COMMENT '权限名称',
  `mname` varchar(20) NOT NULL COMMENT '模块名称',
  `cname` varchar(20) NOT NULL COMMENT '控制器名称',
  `aname` varchar(20) NOT NULL COMMENT '方法名称',
  `parentid` mediumint(5) NOT NULL DEFAULT '0' COMMENT '上级权限的id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sp_privilege`
--

INSERT INTO `sp_privilege` (`id`, `pri_name`, `mname`, `cname`, `aname`, `parentid`) VALUES
(28, '权限管理', 'Admin', 'Privilege', 'lst', 25),
(18, '常用操作', 'Admin', '0', '0', 0),
(19, '会员管理', 'Admin', 'User', 'lst', 18),
(20, '微信设置', 'Admin', 'Sets', 'upd', 18),
(21, '分享设置', 'Admin', 'Shaset', 'share', 18),
(22, '文章管理', 'Admin', 'Page', 'showlist', 18),
(23, '友情链接', 'Admin', '0', '0', 18),
(24, '广告管理', 'Admin', '0', '0', 18),
(25, '系统管理', 'Admin', '0', '0', 0),
(26, '全局设置', 'Admin', 'System', 'lst', 25),
(27, '角色管理', 'Admin', 'Role', 'lst', 25);

-- --------------------------------------------------------

--
-- 表的结构 `sp_role`
--

DROP TABLE IF EXISTS `sp_role`;
CREATE TABLE IF NOT EXISTS `sp_role` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `rolename` varchar(20) NOT NULL COMMENT '角色名称',
  `pri_id_list` varchar(60) NOT NULL COMMENT '权限列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sp_role`
--

INSERT INTO `sp_role` (`id`, `rolename`, `pri_id_list`) VALUES
(1, '超级管理员', '*'),
(2, 'test', '18,21,22'),
(3, '普通管理员', '25,28,26,27');

-- --------------------------------------------------------

--
-- 表的结构 `sp_sets`
--

DROP TABLE IF EXISTS `sp_sets`;
CREATE TABLE IF NOT EXISTS `sp_sets` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `appid` varchar(255) DEFAULT NULL COMMENT 'appid',
  `appsecret` varchar(255) DEFAULT '4546g' COMMENT 'appsecret',
  `file_upload` text COMMENT '文件上传',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='微信设置表';

--
-- 转存表中的数据 `sp_sets`
--

INSERT INTO `sp_sets` (`id`, `appid`, `appsecret`, `file_upload`) VALUES
(1, 'wx49b6e91305b92b8bs', 'c812fba9b075132f4ea4f4af2d828bb6', './abcdEF.txt');

-- --------------------------------------------------------

--
-- 表的结构 `sp_share`
--

DROP TABLE IF EXISTS `sp_share`;
CREATE TABLE IF NOT EXISTS `sp_share` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `share_title` varchar(255) DEFAULT NULL COMMENT '标题',
  `share_link` varchar(255) DEFAULT NULL COMMENT '链接',
  `share_desc` varchar(255) DEFAULT NULL COMMENT '简介',
  `share_image` varchar(255) DEFAULT NULL COMMENT '图片',
  `share_name` varchar(255) DEFAULT NULL COMMENT '页面名称',
  `xs_link` varchar(255) DEFAULT NULL,
  `cnzz` text,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='分享表';

--
-- 转存表中的数据 `sp_share`
--

INSERT INTO `sp_share` (`id`, `share_title`, `share_link`, `share_desc`, `share_image`, `share_name`, `xs_link`, `cnzz`, `title`, `content`) VALUES
(1, 'hitw', '456', '45', '45', '88', '45', '5', '英国女王与特朗普阅兵，后者意外“挡道”', '&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;特朗普去了英国，成为女王伊丽莎白二世会见的第12位美国总统。g&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;一般来说，要抢女王风头是非常困难的，但特朗普做到了。&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;综合外媒报道，当地时间7月13日，特朗普在温莎城堡与伊丽莎白二世会面，在欢迎仪式上，女王与特朗普一同检阅仪仗队。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;large&quot; data-loadfunc=&quot;0&quot; src=&quot;https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=641404915,4267540154&amp;fm=173&amp;app=25&amp;f=JPEG?w=620&amp;h=399&amp;s=C7309AE01F728FDC12D04CA703007042&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; width: 537px; display: block;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;女王开始走在特朗普身后，不知是否为了等女王，特朗普突然停下来，伊丽莎白二世不得不绕着他走。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;normal&quot; width=&quot;320px&quot; data-loadfunc=&quot;0&quot; src=&quot;https://hiphotos.baidu.com/feed/pic/item/e850352ac65c10380258ff2bbe119313b07e8930.jpg&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; display: block; margin: 0px auto;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;走到特朗普身边时，女王向他做了个手势，似乎示意他继续向前走。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;normal&quot; width=&quot;333px&quot; data-loadfunc=&quot;0&quot; src=&quot;https://hiphotos.baidu.com/feed/pic/item/9825bc315c6034a80c78b368c713495408237644.jpg&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; display: block; margin: 0px auto;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;之后，两人一同检阅仪仗队，92岁高龄的女王步速明显更快。&lt;/p&gt;&lt;div class=&quot;img-container&quot; style=&quot;margin-top: 30px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px; white-space: normal;&quot;&gt;&lt;img class=&quot;normal&quot; width=&quot;319px&quot; data-loadfunc=&quot;0&quot; src=&quot;https://hiphotos.baidu.com/feed/pic/item/9345d688d43f8794226543c7de1b0ef41ad53a44.jpg&quot; data-loaded=&quot;0&quot; style=&quot;border: 0px; display: block; margin: 0px auto;&quot;/&gt;&lt;/div&gt;&lt;p style=&quot;margin-top: 26px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;早前，特朗普在接受英国《太阳报》采访时，称赞伊丽莎白二世是个“了不起的女人”，他说“我真的很期待见到她，我认为她很好地代表了她的国家。”&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;“她从未犯过错误，不会有令人尴尬的事情，她是个不可思议的女人。”&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;媒体也没放过一切“黑”特朗普的机会。据路透社报道，当天女王是“微笑着迎接”特朗普和梅拉尼娅夫妇的，不过在等候他们到来时候，还是看了眼手表。&lt;/p&gt;&lt;p style=&quot;margin-top: 22px; margin-bottom: 0px; padding: 0px; line-height: 24px; color: rgb(51, 51, 51); text-align: justify; font-family: arial; white-space: normal;&quot;&gt;本文系观察者网独家稿件，未经授权，不得转载。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;'),
(2, '你号了吗了你发的了的', 'fghjhgf', 'dfghjhgrr', 'fghjhgf', NULL, NULL, NULL, NULL, NULL),
(3, '你号了吗了你发的了啊', 'fghjhgf', 'dfghjhgrr', 'fghjhgf', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `sp_user`
--

DROP TABLE IF EXISTS `sp_user`;
CREATE TABLE IF NOT EXISTS `sp_user` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `username` varchar(32) NOT NULL COMMENT '姓名',
  `pwd` varchar(32) NOT NULL COMMENT '密码',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `roleid` mediumint(5) NOT NULL COMMENT '角色id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `sp_user`
--

INSERT INTO `sp_user` (`id`, `username`, `pwd`, `status`, `roleid`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 1, 1),
(2, 'tom', 'e10adc3949ba59abbe56e057f20f883e', 1, 3),
(4, '袁江平', 'e10adc3949ba59abbe56e057f20f883e', 1, 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
